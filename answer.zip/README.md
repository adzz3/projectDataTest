# FX Deals Import - Starter Project

This starter project implements a Spring Boot service to import FX deals into a Postgres database.
It includes:
- CSV and JSON endpoints to import deals.
- Per-row validation and per-row persistence (no rollback across multiple rows).
- Deduplication via DB unique constraint on `deal_unique_id`.
- Sample CSV, Postman collection, and k6 script.

## Quick start

1. Start Postgres:
```
make up
```

2. Build and run the application:
```
mvn spring-boot:run
```

3. Import sample CSV using Postman or curl:
```
curl -v -F file=@sample/sample-deals.csv http://localhost:8080/api/deals/import
```

## Files of interest
- `docker-compose.yml` - launches Postgres
- `Makefile` - convenience commands
- `pom.xml` - Maven build with JaCoCo (coverage)
- `k6/script.js` - K6 performance script (example)
- `postman_collection.json` - Postman collection with examples
- `sample/sample-deals.csv` - sample input CSV

## JaCoCo coverage
The `pom.xml` includes a JaCoCo rule that is currently global. For the assignment, you should scope the JaCoCo check to only the packages implementing parsing/validation/import logic so the coverage target is achievable. See comments in `pom.xml` and adjust the `<includes>` in JaCoCo configuration.

## Notes & Limitations
- This is a starter project scaffold. Tests are minimal but demonstrate structure.
- The service intentionally saves each row individually and catches unique-constraint violations to avoid rollback across rows.
- For production/high-concurrency, consider `INSERT ... ON CONFLICT DO NOTHING` or other upsert mechanisms.

