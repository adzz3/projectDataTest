package com.example.fxdeals.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "deals", uniqueConstraints = @UniqueConstraint(columnNames = {"deal_unique_id"}))
public class DealEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "deal_unique_id", nullable = false, unique = true)
    private String dealUniqueId;

    @Column(name = "from_currency", nullable = false)
    private String fromCurrency;

    @Column(name = "to_currency", nullable = false)
    private String toCurrency;

    @Column(name = "deal_timestamp", nullable = false)
    private Instant dealTimestamp;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    public DealEntity() {}

    public DealEntity(String dealUniqueId, String fromCurrency, String toCurrency, Instant dealTimestamp, BigDecimal amount) {
        this.dealUniqueId = dealUniqueId;
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.dealTimestamp = dealTimestamp;
        this.amount = amount;
    }

    // getters and setters
    public Long getId() { return id; }
    public String getDealUniqueId() { return dealUniqueId; }
    public String getFromCurrency() { return fromCurrency; }
    public String getToCurrency() { return toCurrency; }
    public Instant getDealTimestamp() { return dealTimestamp; }
    public BigDecimal getAmount() { return amount; }

    public void setId(Long id) { this.id = id; }
    public void setDealUniqueId(String dealUniqueId) { this.dealUniqueId = dealUniqueId; }
    public void setFromCurrency(String fromCurrency) { this.fromCurrency = fromCurrency; }
    public void setToCurrency(String toCurrency) { this.toCurrency = toCurrency; }
    public void setDealTimestamp(Instant dealTimestamp) { this.dealTimestamp = dealTimestamp; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}
