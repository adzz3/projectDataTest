package com.example.fxdeals.service;

import java.util.List;

public class ImportResult {
    public int success;
    public List<String> duplicates;
    public List<String> failures;

    public ImportResult(int success, List<String> duplicates, List<String> failures) {
        this.success = success;
        this.duplicates = duplicates;
        this.failures = failures;
    }
}
