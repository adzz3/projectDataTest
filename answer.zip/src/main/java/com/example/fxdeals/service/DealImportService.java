package com.example.fxdeals.service;

import com.example.fxdeals.dto.DealDto;
import com.example.fxdeals.entity.DealEntity;
import com.example.fxdeals.repository.DealRepository;
import com.example.fxdeals.validation.DealValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DealImportService {
    private final DealRepository repo;
    private final DealValidator validator;
    private final Logger log = LoggerFactory.getLogger(getClass());

    public DealImportService(DealRepository repo) {
        this.repo = repo;
        this.validator = new DealValidator();
    }

    public ImportResult importDeals(List<DealDto> deals) {
        List<String> failures = new ArrayList<>();
        List<String> duplicates = new ArrayList<>();
        int success = 0;
        for (DealDto dto : deals) {
            try {
                validator.validate(dto);
                DealEntity entity = new DealEntity(dto.dealUniqueId, dto.fromCurrency, dto.toCurrency, dto.dealTimestamp, dto.amount);
                try {
                    repo.save(entity);
                    success++;
                } catch (DataIntegrityViolationException e) {
                    duplicates.add(dto.dealUniqueId);
                    log.warn("Duplicate detected for {}", dto.dealUniqueId);
                }
            } catch (Exception ex) {
                failures.add("dealId=" + (dto == null ? "null" : dto.dealUniqueId) + " error=" + ex.getMessage());
                log.error("Failed to import {} : {}", (dto == null ? "null" : dto.dealUniqueId), ex.getMessage());
            }
        }
        return new ImportResult(success, duplicates, failures);
    }
}
