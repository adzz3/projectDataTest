package com.example.fxdeals.validation;

public class ValidationException extends RuntimeException {
    public ValidationException(String msg) { super(msg); }
}
