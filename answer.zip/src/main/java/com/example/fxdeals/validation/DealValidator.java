package com.example.fxdeals.validation;

import com.example.fxdeals.dto.DealDto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class DealValidator {
    public void validate(DealDto dto) {
        List<String> errors = new ArrayList<>();
        if (dto == null) throw new ValidationException("payload is null");
        if (dto.dealUniqueId == null || dto.dealUniqueId.isBlank()) errors.add("dealUniqueId missing");
        if (!isIsoCurrency(dto.fromCurrency)) errors.add("fromCurrency invalid");
        if (!isIsoCurrency(dto.toCurrency)) errors.add("toCurrency invalid");
        if (dto.amount == null || dto.amount.compareTo(BigDecimal.ZERO) <= 0) errors.add("amount must be > 0");
        if (dto.dealTimestamp == null) errors.add("dealTimestamp missing");
        if (!errors.isEmpty()) throw new ValidationException(String.join("; ", errors));
    }

    private boolean isIsoCurrency(String c) {
        return c != null && c.matches("^[A-Z]{3}$");
    }
}
