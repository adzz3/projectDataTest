package com.example.fxdeals.dto;

import java.math.BigDecimal;
import java.time.Instant;

public class DealDto {
    public String dealUniqueId;
    public String fromCurrency;
    public String toCurrency;
    public Instant dealTimestamp;
    public BigDecimal amount;

    public DealDto() {}

    public DealDto(String dealUniqueId, String fromCurrency, String toCurrency, Instant dealTimestamp, BigDecimal amount) {
        this.dealUniqueId = dealUniqueId;
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.dealTimestamp = dealTimestamp;
        this.amount = amount;
    }
}
