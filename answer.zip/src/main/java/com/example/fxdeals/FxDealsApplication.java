package com.example.fxdeals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FxDealsApplication {
    public static void main(String[] args) {
        SpringApplication.run(FxDealsApplication.class, args);
    }
}
