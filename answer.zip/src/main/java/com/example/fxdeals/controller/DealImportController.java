package com.example.fxdeals.controller;

import com.example.fxdeals.dto.DealDto;
import com.example.fxdeals.parser.CsvDealParser;
import com.example.fxdeals.service.DealImportService;
import com.example.fxdeals.service.ImportResult;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/deals")
public class DealImportController {

    private final DealImportService service;
    private final CsvDealParser parser = new CsvDealParser();

    public DealImportController(DealImportService service) {
        this.service = service;
    }

    @PostMapping(value = "/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ImportResult> importCsv(@RequestPart("file") MultipartFile file) throws IOException {
        List<DealDto> dtos = parser.parse(file.getInputStream());
        ImportResult res = service.importDeals(dtos);
        return ResponseEntity.ok(res);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ImportResult> postSingle(@RequestBody DealDto dto) {
        ImportResult res = service.importDeals(List.of(dto));
        return ResponseEntity.status(201).body(res);
    }
}
