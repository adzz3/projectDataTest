package com.example.fxdeals.parser;

import com.example.fxdeals.dto.DealDto;
import com.opencsv.CSVReader;

import java.io.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class CsvDealParser {

    public List<DealDto> parse(InputStream csv) throws IOException {
        try (CSVReader reader = new CSVReader(new InputStreamReader(csv))) {
            List<DealDto> list = new ArrayList<>();
            String[] row;
            int line = 0;
            while ((row = reader.readNext()) != null) {
                line++;
                if (line == 1 && isHeader(row)) continue;
                if (row.length < 5) throw new IllegalArgumentException("Row " + line + " has insufficient columns");
                String dealUniqueId = row[0].trim();
                String from = row[1].trim();
                String to = row[2].trim();
                Instant ts;
                try {
                    ts = Instant.parse(row[3].trim());
                } catch (Exception e) {
                    throw new IllegalArgumentException("Row " + line + ": invalid timestamp");
                }
                BigDecimal amount;
                try {
                    amount = new BigDecimal(row[4].trim());
                } catch (Exception e) {
                    throw new IllegalArgumentException("Row " + line + ": invalid amount");
                }
                list.add(new DealDto(dealUniqueId, from, to, ts, amount));
            }
            return list;
        }
    }

    private boolean isHeader(String[] row) {
        if (row.length == 0) return false;
        return row[0].toLowerCase().contains("deal");
    }
}
