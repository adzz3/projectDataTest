package com.example.fxdeals.validation;

import com.example.fxdeals.dto.DealDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class DealValidatorTest {

    @Test
    void validDealDoesNotThrow() {
        DealDto dto = new DealDto("D-1","USD","EUR", Instant.parse("2024-09-01T10:00:00Z"), new BigDecimal("1000"));
        DealValidator v = new DealValidator();
        assertDoesNotThrow(() -> v.validate(dto));
    }

    @Test
    void invalidCurrencyThrows() {
        DealDto dto = new DealDto("D-2","US","EUR", Instant.parse("2024-09-01T10:00:00Z"), new BigDecimal("1000"));
        DealValidator v = new DealValidator();
        assertThrows(ValidationException.class, () -> v.validate(dto));
    }
}
