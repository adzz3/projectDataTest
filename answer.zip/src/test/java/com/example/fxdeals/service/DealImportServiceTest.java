package com.example.fxdeals.service;

import com.example.fxdeals.dto.DealDto;
import com.example.fxdeals.entity.DealEntity;
import com.example.fxdeals.repository.DealRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.dao.DataIntegrityViolationException;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class DealImportServiceTest {

    @Test
    void duplicateHandled() {
        DealRepository repo = Mockito.mock(DealRepository.class);
        Mockito.when(repo.save(any(DealEntity.class))).thenThrow(new DataIntegrityViolationException("unique"));
        DealImportService s = new DealImportService(repo);
        DealDto dto = new DealDto("D-1","USD","EUR", Instant.parse("2024-09-01T10:00:00Z"), new BigDecimal("1000"));
        ImportResult r = s.importDeals(List.of(dto));
        assertEquals(0, r.success);
        assertEquals(1, r.duplicates.size());
    }
}
