package com.example.fxdeals.parser;

import com.example.fxdeals.dto.DealDto;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CsvDealParserTest {

    @Test
    void parseValidCsv() throws Exception {
        String csv = "dealUniqueId,fromCurrency,toCurrency,dealTimestamp,amount\nD-1,USD,EUR,2024-09-01T10:00:00Z,1000\n";
        CsvDealParser p = new CsvDealParser();
        List<DealDto> list = p.parse(new ByteArrayInputStream(csv.getBytes()));
        assertEquals(1, list.size());
        assertEquals("D-1", list.get(0).dealUniqueId);
    }

    @Test
    void parseBadTimestampThrows() {
        String csv = "dealUniqueId,fromCurrency,toCurrency,dealTimestamp,amount\nD-1,USD,EUR,badts,1000\n";
        CsvDealParser p = new CsvDealParser();
        assertThrows(Exception.class, () -> p.parse(new ByteArrayInputStream(csv.getBytes())));
    }
}
