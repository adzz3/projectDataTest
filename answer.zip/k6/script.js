import http from "k6/http";
import { check } from "k6";

export let options = {
  vus: 10,
  duration: "15s",
};

export default function () {
  let file = open("sample/sample-deals.csv", "b");
  let url = "http://localhost:8080/api/deals/import";
  let payload = { file: http.file(file, "sample-deals.csv", "text/csv") };
  let res = http.post(url, payload);
  check(res, { "status 200": (r) => r.status === 200 });
}
